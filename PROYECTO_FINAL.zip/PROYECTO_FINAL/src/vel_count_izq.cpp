#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"
//#include "master_package_iele3338/GPIOClass.h"

#include <bits/stdc++.h>
#include <iostream>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <bits/stdc++.h> 
#include <chrono>
#include "wiringPi.h"

#define GPIO_CLASS_H
#define Time chrono::time_point<std::chrono::system_clock>
using namespace std; 

constexpr double Pi = std::acos(-1);




/**
 * This tutorial demonstrates simple sending of messages over the ROS system.
 */
int main(int argc, char **argv)
{
  /**
   * The ros::init() function needs to see argc and argv so that it can perform
   * any ROS arguments and name remapping that were provided at the command line.
   * For programmatic remappings you can use a different version of init() which takes
   * remappings directly, but for most command-line programs, passing argc and argv is
   * the easiest way to do it.  The third argument to init() is the name of the node.
   *
   * You must call one of the versions of ros::init() before using any other
   * part of the ROS system.
   */
  ros::init(argc, argv, "izq_vel");

  /**
   * NodeHandle is the main access point to communications with the ROS system.
   * The first NodeHandle constructed will fully initialize this node, and the last
   * NodeHandle destructed will close down the node.
   */
  ros::NodeHandle n;

  /**
   * The advertise() function is how you tell ROS that you want to
   * publish on a given topic name. This invokes a call to the ROS
   * master node, which keeps a registry of who is publishing and who
   * is subscribing. After this advertise() call is made, the master
   * node will notify anyone who is trying to subscribe to this topic name,
   * and they will in turn negotiate a peer-to-peer connection with this
   * node.  advertise() returns a Publisher object which allows you to
   * publish messages on that topic through a call to publish().  Once
   * all copies of the returned Publisher object are destroyed, the topic
   * will be automatically unadvertised.
   *
   * The second parameter to advertise() is the size of the message queue
   * used for publishing messages.  If messages are published more quickly
   * than we can send them, the number here specifies how many messages to
   * buffer up before throwing some away.
   */
  ros::Publisher pub = n.advertise<std_msgs::Float32>("vel_izq", 10);

  ros::Rate loop_rate(10);

  /**
   * A count of how many messages we have sent. This is used to create
   * a unique string for each message.
   */
  int count = 0;

  int nflancos= 40;
  int count1 = 0, count2 = 0;
  int act1 = 0, act2 = 0, ant1 =0;
  double direc = 1, dts, periodos, T,vel, RPM ;

  string val;

  Time tiempois, tiempos;
  chrono::duration<double> diff; 
  std_msgs::Float32 msg;

wiringPiSetupGpio();
pinMode(19,INPUT);
pinMode(26,INPUT);

  while (ros::ok())
  {
    /**
     * This is a message object. You stuff it with data, and then publish it.
     */

    act1 = digitalRead(19);
    act2 = digitalRead(26);
    

    if (count1 ==0){
		  tiempois =chrono::system_clock::now();
    }
	  if (act1 >ant1){

      count1++;
      if (act2<act1){
        direc = -1;
      }
      else{
        direc = 1;
      }
    }

    if (count1 >= nflancos){
	    tiempos = chrono::system_clock::now();
	    diff = tiempos-tiempois;
      dts = diff.count();
	    periodos = dts/double(count1);
	    vel = (2.0*Pi)/(442.0*periodos);
	    T = (2.0*Pi)/(vel);
      RPM = direc*vel*30.0/Pi;
      msg.data = vel;
	    pub.publish(msg);

      count1 = 0;
    }
ant1=act1;
    
    ros::spinOnce();

    //loop_rate.sleep();

  }


  return 0;
}
	