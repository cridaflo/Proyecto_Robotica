#! /bin/sh

source /opt/ros/kinetic/setup.bash
source ~/catkin_ws/devel/setup.bash
roslaunch PROYECTO_FINAL vive_robot.launch