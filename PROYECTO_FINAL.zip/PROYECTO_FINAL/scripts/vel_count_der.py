#!/usr/bin/env python

import rospy

from std_msgs.msg import Float32
import time, math
import  RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(6, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


nflancos= 50
d
def talker():
    global nflancos
    pub = rospy.Publisher('vel_der', Float32, queue_size=10)
    rospy.init_node('der_vel', anonymous=True)
    rate = rospy.Rate(40) # 10hz
    
    vel = 0
    count = 0
    ant = 0
    tiempois = time.time()
    tiempos=  0
    count2 = 0
    act2 = 0
    ant2 = 0
    tiempo1 =time.time()
    tiempos1 =time.time()
    tiempo2 = time.time()
    tiempos2 =time.time()
    print("holi")	
    while not rospy.is_shutdown():
	act  = GPIO.input(5)
	act2  = GPIO.input(6)
	if count ==0:
	    tiempois =time.time()
	if act >ant:
            count = count +1
	    tiempos1 = time.time()
	    tiempo1 = tiempos1-tiempos2 

	if act2  > ant2:
	    tiempos2 = time.time()	
	    tiempo2 = tiempos2-tiempos1
	if count >= nflancos:
	    counts=count
	    tiempos = time.time()
	    dts = tiempos-tiempois
	    periodos = dts/float(counts)
	    print(tiempo,tiempois)
	    vel = (2*math.pi)/(442.0*periodos)
	    t = (2*math.pi)/(vel)
            rospy.loginfo("periodo: %s, tiempo1:%s, tiempo2, %s",t, tiempo1, tiempo2)
	    if tiempo1< tiempo2:
		vel = -1*vel
            count = 0

	#elif  (time.time()-tiempois)>1:
	 #   vel =0
	   # count =0
	   
            
	pub.publish(vel)
	ant = act
        #rospy.loginfo(hello_str)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
