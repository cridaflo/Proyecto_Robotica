#!/usr/bin/env python
# Software License Agreement (BSD License)
#
# Copyright (c) 2008, Willow Garage, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Willow Garage, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Revision $Id$

## Simple talker demo that published std_msgs/Strings messages
## to the 'chatter' topic

import rospy
import time
import math
from std_msgs.msg import Int32

import  RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(24, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

countb = 0
acumb =0
nflancos = 50
tiempob =0
tiempoib  = 0

counts = 0
acums =0
tiempos =0
tiempois  = 0

def flancob(channel):
    global countb, acumb, tiempob, tiempoib
    if acumb ==0:
	tiempoib=time.time()
    else:
	tiempob =time.time()
    acumb= acumb +1

def flancos(channel):
    global counts, acums, tiempos, tiempois
    if acums ==0:
	tiempois=time.time()
    else:
	tiempos =time.time()
    acums = acums +1


GPIO.add_event_detect(24, GPIO.FALLING, callback=flancob)
GPIO.add_event_detect(23, GPIO.RISING, callback=flancos)

def talker():
    global countb, acumb, tiempob, tiempoib,counts, acums, tiempos, tiempois
    pub = rospy.Publisher('chatter', Int32, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(1000000) # 10hz
    while not rospy.is_shutdown():
	acumb =0
	#acums = 0
        while    0*acums<= nflancos and acumb<=nflancos :
            pass            
	#dts = tiempos-tiempois
	dtb = 	tiempob-tiempoib
	#periodos = dts/float(acums)
	periodob = dtb/float(acumb)
	#vels = (2*math.pi)/(442.0*periodos)
	velb = (2*math.pi)/(442.0*periodob)
	vel = (velb+velb)/2.0
	t = (2*math.pi)/(vel)
        rospy.loginfo(t)
        

        #rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
