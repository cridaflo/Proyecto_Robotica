#!/usr/bin/env python
#primero roscore
#luego pacman en challenge
#rosrun Tutorial nodo_teclado.py
import rospy
from std_msgs.msg import Float32
import RPi.GPIO as GPIO

#variables de control
tamBuffer = 1000

deseo = 5#setpoint
vel =0 # s. entrada
kd = 5
kp = 35
ki = 10

division = 100

GPIO.setmode(GPIO.BCM)
GPIO.setup(2, GPIO.OUT)#adelante
adelante  = GPIO.PWM(2,division)
adelante.start(0) 
GPIO.setup(3, GPIO.OUT)#atras
atras=  GPIO.PWM(3,division)
atras.start(0)
#variable que almacena la direccion en la que se mueve pacman





def asignarDeseo (msg): #asigna el setpoint
    global deseo
    #deseo = msg.data	
    pass

def asignarVel(msg): #asigna la velocidad de entrada
    global vel
    vel = msg.data

#funcion principal para controlar el pacman
def vel_controller():
    global deseo, vel , tamBuffer #variables setpoint, velocidad
    #Se inicia el nodo, y se conecta con el topico pacmanActions0 donde va a publicar
    rospy.init_node('controller_py', anonymous=True) #crea nodo

    rospy.Subscriber('DeseoIzquierdo', Float32, asignarDeseo)
    rospy.Subscriber('vel_izq', Float32, asignarVel)
    try:
	tasa =10
        rate = rospy.Rate(tasa)  # 10hz
        
        error_acum = []
        error_ant = 0
	salida = 0
 	integral = 0
        while not rospy.is_shutdown():            
            error = deseo-vel #s. error		
            error_acum.insert(0,error)
	    integral = integral + error
	    while len(error_acum)>tamBuffer:
		integral = integral-error_acum.pop()

	    integral = integral /float(tasa)
            derivda = (error-error_ant)*float(tasa)
            salida = kp*error+ki*integral+derivda*kd
	    control = min(20,int(abs(salida)))
            #rospy.loginfo("error : %s, control : %s ", error, control)
	    if salida<0:
		atras.ChangeDutyCycle(control )
		adelante.ChangeDutyCycle(0)
	    else:		
		adelante.ChangeDutyCycle(control )
		atras.ChangeDutyCycle(0)

	  
            error_ant=error
            rate.sleep()

    except rospy.ServiceException as e:
        print("Error!! Make sure pacman_world node is running ")


if __name__ == '__main__':
    try:
        vel_controller()
    except rospy.ROSInterruptException:
        pass
