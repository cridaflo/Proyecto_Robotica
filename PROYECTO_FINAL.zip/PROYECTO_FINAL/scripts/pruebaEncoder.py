#!/usr/bin/env python


import rospy
from multiprocessing import *

from std_msgs.msg import Float32
import time, math
import  RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(24, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


nflancos= 442
a = Pipe()
def talker(conn):
    count = 0
    act=0
    ant = 0
    print('Llega SNIff')
    while not rospy.is_shutdown():
	act  = GPIO.input(24)
	act2  = GPIO.input(23)
	print(act)
	if act >ant:
            count = count +1
            print('Ruben careverga2')

	     
	if count >= nflancos:
	    count=0
            conn.send( 'a')
            print('Ruben careverga')
        ant=act


def sender(conn):
    pub = rospy.Publisher('vel_izq', Float32, queue_size=1)
    tiempois = time.time()
    tiemposs =0

    while True:
        if conn.recv():
            tiempos = time.time()
	    dts = tiempos-tiempois
	    periodos = dts/442
	    vel = (2*math.pi)/(periodos)
	    t = (2*math.pi)/(vel)
            rospy.loginfo("periodo: %s, tiempo1:%s, tiempo2, %s",t, tiempo1, tiempo2)
            pub.publish(dts) 

if __name__ == '__main__':
    #a = Pipe()
    try:
        receiver_conn, sender_conn= a
        p=Process(target=talker, args=(sender_conn,))
        p.start()
        sender(receiver_conn)
    except rospy.ROSInterruptException:
        pass
