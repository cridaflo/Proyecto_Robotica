#!/usr/bin/env python
#primero roscore
#luego pacman en challenge
#rosrun Tutorial nodo_teclado.py
import rospy
from std_msgs.msg import Float32, Int32
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.OUT)#adelante
adelante  = GPIO.PWM(17,100)
adelante.start(100) 
GPIO.setup(27, GPIO.OUT)#atras
atras=  GPIO.PWM(27,100)
atras.start(100)
#variable que almacena la direccion en la que se mueve pacman

#variables de control
tamBuffer = 1000
deseo = 0#setpoint
vel =0 # s. entrada
kd = 0.1
kp = 1
ki = 0.3
negativo = 1

estado = 0

def asignarDeseo (msg): #asigna el setpoint
    global deseo
    deseo = msg.data
    pass

def asignarVel(msg): #asigna la velocidad de entrada
    global vel
    vel = msg.data

def cambiarEstado(msg):
    global estado
    estado = msg.data

#funcion principal para controlar el pacman
def vel_controller():
    global deseo, vel, estado , tamBuffer #variables setpoint, velocidad
    #Se inicia el nodo, y se conecta con el topico pacmanActions0 donde va a publicar
    rospy.init_node('controller_py', anonymous=True) #crea nodo

    rospy.Subscriber('deseo_der', Float32, asignarDeseo)
    rospy.Subscriber('vel_der', Float32, asignarVel)
    rospy.Subscriber('el_estado', Int32, cambiarEstado)
    pub = rospy.Publisher('vel_debug_der', Float32, queue_size=10)
    try:
        rate = rospy.Rate(15)  # 10hz
        
        error_acum = []
        error_ant = 0
	salida = 0
	integral = 0
        while not rospy.is_shutdown():
	    if estado ==2:
	        if salida < 0:
		    negativo = -1
                else:
		    negativo = 1
                error = deseo-vel *negativo#s. error
                integral += error
                error_acum.insert(0,error)
	        while len(error_acum)>tamBuffer:
		    integral -=error_acum.pop()

                derivda = error-error_ant
                salida = 0*(kp*error+ki*integral+derivda*kd)
            #salida = 100
		control = min(100,int(abs(salida)))
            #rospy.loginfo("error : %s, control : %s ", error, control)
	        if salida<0:
		    atras.ChangeDutyCycle(control )
		    adelante.ChangeDutyCycle(0)
	        else:		
		    adelante.ChangeDutyCycle(control )
		    atras.ChangeDutyCycle(0)
	    #print(vel*negativo)
	        pub.publish(vel*negativo)
                error_ant=error
	    else:
		    adelante.ChangeDutyCycle(0 )
		    atras.ChangeDutyCycle(0)	
            rate.sleep()

    except rospy.ServiceException as e:
        print("Error!! Make sure pacman_world node is running ")


if __name__ == '__main__':
    try:
        vel_controller()
    except rospy.ROSInterruptException:
        pass
