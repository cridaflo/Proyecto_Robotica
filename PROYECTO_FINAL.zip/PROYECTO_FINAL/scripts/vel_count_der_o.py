#!/usr/bin/env python

import rospy

from std_msgs.msg import Float32
import time, math
import  RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(21, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(20, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setwarnings(False)

nflancos= 50
count =0
count2 = 0




def callback1(msg):
    global count
    count=count+1

def callback2(msg):
    global count2
    count2=count2+1
    
def talker():
    global nflancos
    global count
    global count2
    pub = rospy.Publisher('vel_der', Float32, queue_size=10)
    rospy.init_node('der_vel', anonymous=True)
    rate = rospy.Rate(100) # 10hz
    count = 0
    ant = 0
    tiempois = 0
    tiempos=  0
    count2 = 0
    direc = 1
    GPIO.add_event_detect(21, GPIO.RISING, callback=callback1)
    GPIO.add_event_detect(20,GPIO.RISING, callback=callback2)

    
    while not rospy.is_shutdown():
	#act  = GPIO.input(13)
	#act2  = GPIO.input(6)
	#print(act)
	if count ==0:
		tiempois =time.time()
	#if act >ant:
            #count = count +1
            #if act2<act:
                #direc = -1
            #else:
                #direc = 1
	t=time.time()
               
	if count >= nflancos:
	    counts=count
	    tiempos = time.time()
	    dts = tiempos-tiempois
	    periodos = dts/float(counts)
	    vel = (2*math.pi)/(442.0*periodos)
	    t = (2*math.pi)/(vel)
            #rospy.loginfo(t)
	    pub.publish(direc*vel*30.0/math.pi)
            count = 0	
            
         
	#ant = act
        #rospy.loginfo(hello_str)
        #rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
