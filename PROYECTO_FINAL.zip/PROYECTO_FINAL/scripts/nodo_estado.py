#!/usr/bin/env python

import rospy
import sys
import threading
from master_msgs_iele3338.msg import Obstacle
from master_msgs_iele3338.srv import AckService, StartService
from std_msgs.msg import Float64, Int32
from std_msgs.msg import Float32MultiArray, Float32
from geometry_msgs.msg import Twist
import numpy as np
import threading
import time
import os
import matplotlib.pyplot as plt
import math
import Queue as queue
import RPi.GPIO as GPIO

GPIO1 = 7
GPIO2 = 8
GPIO3 = 25

GPIO.setmode(GPIO.BCM)

GPIO.setup(GPIO1, GPIO.OUT)
GPIO.setup(GPIO2, GPIO.OUT)
GPIO.setup(GPIO3, GPIO.OUT)

c1 = GPIO.PWM(GPIO1,100)
c2 = GPIO.PWM(GPIO2,100)
c3 = GPIO.PWM(GPIO3,100)

c1.start(0)
c2.start(0)
c3.start(0) 

estado = 0

def estadoCallback(msg):
    global estado    
    estado = msg.data

def estado0():
    #print(0)
    global c1,c2,c3
    c1.ChangeDutyCycle(100)
    c2.ChangeDutyCycle(0)
    c3.ChangeDutyCycle(0)
    pass

def estado1():
    #print(1)
    global c1,c2,c3
    c1.ChangeDutyCycle(0)
    c2.ChangeDutyCycle(100)
    c3.ChangeDutyCycle(0)
    pass

def estado2():
    #print(2)
    global c1,c2,c3
    c1.ChangeDutyCycle(0)
    c2.ChangeDutyCycle(0)
    c3.ChangeDutyCycle(100)
    pass

def estado3():
    #print(3)
    global c1,c2,c3
    c1.ChangeDutyCycle(50)
    c2.ChangeDutyCycle(50)
    c3.ChangeDutyCycle(50)

    pass

def estado4():
    #print(4)
    global c1,c2,c3
    c1.ChangeDutyCycle(50)
    c2.ChangeDutyCycle(69)
    c3.ChangeDutyCycle(42)

    pass
#funcion principal para controlar el pacman
def manejadorEstados():

    global estado

    rospy.init_node('estado', anonymous=True)
    rospy.Subscriber('el_estado', Int32, estadoCallback)

    try:
       

        rate = rospy.Rate(3)  # 10hz
        
        i = 0
        while not rospy.is_shutdown():
            if estado == 0:
                estado0()
            elif estado ==1:
                estado1()
            elif  estado == 2:
                estado2()
            elif estado == 3:
                estado3()
            elif estado == 4:
                estado4()

            rate.sleep()

    except rospy.ServiceException as e:
        print("Error!!")


if __name__ == '__main__':
    try:
        manejadorEstados()
    except rospy.ROSInterruptException:
        pass
