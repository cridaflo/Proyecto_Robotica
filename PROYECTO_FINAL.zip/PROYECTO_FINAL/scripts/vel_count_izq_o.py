#!/usr/bin/env python

from std_msgs.msg import Float32
import rospy
import time, math
import  RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(24, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


nflancos= 50

def talker():
    global nflancos
    pub = rospy.Publisher('vel_izq', Float32, queue_size=10)
    rospy.init_node('izq_vel', anonymous=True)
    rate = rospy.Rate(100) # 10hz
    count = 0
    ant = 0
    tiempois = 0
    tiempos=  0
    count2 = 0
    direc = 1
    while not rospy.is_shutdown():
	act  = GPIO.input(24)
	act2 = GPIO.input(23)
	if count ==0:
		tiempois =time.time()
	if act >ant:
            count = count +1
            if act2 < act:
                direc = -1
            else:

                direc = 1
            
            
	if count >= nflancos:
	    counts=count
	    tiempos = time.time()
	    dts = tiempos-tiempois
	    periodos = dts/float(counts)
	    vel = (2*math.pi)/(442.0*periodos)
	    t = (2*math.pi)/(vel)
            #rospy.loginfo(t)
	    pub.publish(direc*vel*30.0/math.pi)
            count = 0	
            
         
	ant = act
        #rospy.loginfo(hello_str)
        #rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
