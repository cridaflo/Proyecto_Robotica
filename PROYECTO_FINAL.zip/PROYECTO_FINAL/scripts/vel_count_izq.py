#!/usr/bin/env python


import rospy

from std_msgs.msg import Float32
import time, math
import  RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(24, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(23, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


nflancos= 40

def talker():
    global nflancos
    pub = rospy.Publisher('vel_izq', Float32, queue_size=1)
    rospy.init_node('izq_vel', anonymous=True)
    rate = rospy.Rate(1000) # 10hz
    
    count = 0
    ant = 0
    tiempois = 0
    tiemposs =0
    count2 = 0
    act2 = 0
    ant2 = 0
    tiempo1 =time.time()
    tiempos1 =time.time()
    tiempo2 = time.time()
    tiempos2 =time.time()
    #print("holi")
    vel =0
    while not rospy.is_shutdown():
	act  = GPIO.input(24)
	act2  = GPIO.input(23)
	if count ==0:
	     tiempois =time.time()
	
	if act >ant:
            count = count +1
	    tiempos1 = time.time()
	    tiempo1 = tiempos1-tiempos2
	     

	if act2  > ant2:
	    tiempos2 = time.time()
	    tiempo2 = tiempos2-tiempos1
	if count >= nflancos:
	    counts=count
	    tiempos = time.time()
	    dts = tiempos-tiempois
	    periodos = dts/float(counts)
	    vel = (2*math.pi)/(442.0*periodos)
	    t = (2*math.pi)/(vel)
            #rospy.loginfo("periodo: %s, tiempo1:%s, tiempo2, %s",t, tiempo1, tiempo2)
	    
	    if tiempo1> tiempo2:
		vel = -1*vel
	    
            count = 0
	
	elif time.time()-tiempois>1:
	    vel =0
	    pass
	#print(act)   
        pub.publish(vel) 
	ant = act
        #rospy.loginfo(hello_str)
        #rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
